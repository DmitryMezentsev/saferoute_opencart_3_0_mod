<?php

$_['heading_title']    = 'Доставка SafeRoute';

$_['text_extensions']  = 'Расширения';
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Настройки сохранены';
$_['text_edit']        = 'Редактирование';

$_['entry_geo_zone']   = 'Географическая зона';
$_['entry_token']      = 'Токен';
$_['entry_shop_id']    = 'ID магазина';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

$_['error_permission'] = 'У вас недостаточно прав для изменения настроек модуля SafeRoute.';